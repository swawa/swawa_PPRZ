#ifndef CONF_DC_MC_H
#define CONF_DC_MC_H

/* clock in MHz */
#define CLOCK 16


#define LED_1_BANK C
#define LED_1_PIN  3


#endif /* CONF_DC_MC_H */
